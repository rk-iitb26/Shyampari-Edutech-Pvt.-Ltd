import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import HomePage from "./Pages/Home";
import SignUpPage from "./Pages/SignUp"; // create this page
import LoginPage from "./Pages/Login";
import SuccessGrid from "./Pages/FeedBack"


function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/signup" element={<SignUpPage />} />
        <Route path="/feedbacks" element={<SuccessGrid />} />
      </Routes>
    </Router>

  );
}

export default App;
