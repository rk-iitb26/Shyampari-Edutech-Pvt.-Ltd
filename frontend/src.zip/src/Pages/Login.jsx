import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const LoginPage = ({ onClose }) => {
    const [formData, setFormData] = useState({
        username: '',
        password: ''
    });
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState(null);
    const navigate = useNavigate();

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prevData => ({ ...prevData, [name]: value }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        if (!formData.username || !formData.password) {
            setError("Both username and password are required.");
            return;
        }

        setLoading(true);
        setError(null);

        try {
            const response = await axios.post("YOUR_BACKEND_LOGIN_ENDPOINT", formData);
            if (response.data.success) {
                localStorage.setItem('authToken', response.data.token);
                alert("Login successful! Welcome back.");
                navigate("/dashboard");
                if (onClose) onClose();
            } else {
                setError(response.data.message || "Invalid username or password.");
            }
        } catch (err) {
            console.error("Login error:", err);
            setError("Something went wrong. Please try again.");
        } finally {
            setLoading(false);
        }
    };

    const handleSignUp = () => {
        if (onClose) onClose();
        navigate("/signup");
    };

    return (
        <div className="bg-gray-100 min-h-screen flex items-center justify-center font-sans">
            <div className="bg-white p-8 rounded-lg shadow-xl w-full max-w-md">
                <div className="text-center mb-6">
                    <h1 className="text-3xl font-bold text-gray-800">Shampari Edutech Pvt. Ltd</h1>
                    <p className="text-gray-500 mt-2">Log in to your account.</p>
                </div>

                <form onSubmit={handleSubmit}>
                    <div className="mb-4">
                        <label htmlFor="username" className="block text-gray-700 text-sm font-semibold mb-2">Username</label>
                        <input
                            type="text"
                            id="username"
                            name="username"
                            value={formData.username}
                            onChange={handleChange}
                            placeholder="Enter user name"
                            required
                            className="w-full px-4 py-2 border rounded-md text-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
                        />
                    </div>

                    <div className="mb-6">
                        <label htmlFor="password" className="block text-gray-700 text-sm font-semibold mb-2">Password</label>
                        <input
                            type="password"
                            id="password"
                            name="password"
                            value={formData.password}
                            onChange={handleChange}
                            placeholder="Enter password"
                            required
                            className="w-full px-4 py-2 border rounded-md text-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
                        />
                    </div>

                    {error && (
                        <div className="text-red-500 text-sm text-center mb-4">
                            {error}
                        </div>
                    )}

                    <button
                        type="submit"
                        disabled={loading}
                        className="w-full bg-blue-600 text-white font-bold py-2 px-4 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:bg-gray-400 disabled:cursor-not-allowed">
                        {loading ? 'Logging in...' : 'LOGIN'}
                    </button>
                </form>

                <p className="mt-4 text-center text-gray-500 text-sm">
                    Don’t have an account?{' '}
                    <button
                        type="button"
                        onClick={handleSignUp}
                        className="text-blue-600 hover:underline">
                        Sign up now
                    </button>
                </p>

                <p className="mt-1 text-center text-sm text-gray-500">
                    <a href="#" className="text-blue-600 hover:underline">Forgot Password?</a>
                </p>
            </div>
        </div>
    );
};

export default LoginPage;