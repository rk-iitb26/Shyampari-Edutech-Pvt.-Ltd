import NavBar from "../Components/Nav"
import HowItWorks from "../Components/AboutSection"
import MainSection from "../Components/MainSection"
import WhyUs from "../Components/Whyus"
import Footer from "../Components/Footer"
import Testimonials from "../Components/Testimonials"

function HomePage() {
    return (
        <div id="Home">
            <NavBar
                About="About"
                Event="Event"
                Contact="Contacts"
                Feedback="Feedback"
            >
            </NavBar>
            <MainSection imageUrl={"/bgimage.jpg"} />
            <HowItWorks />
            <WhyUs />
            <Testimonials />
            <Footer />

        </div>
    )
}

export default HomePage