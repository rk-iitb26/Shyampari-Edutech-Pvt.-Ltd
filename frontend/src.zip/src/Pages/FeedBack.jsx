// src/Components/SuccessGrid.jsx
import React from 'react';

const successData = [
    { id: 1, imageUrl: '/avatars/avatar1.png', name: 'Rohan Sharma', quote: 'The personalized guidance made all the difference!', cardBackgroundImage: '/img1.jpg' },
    { id: 2, imageUrl: '/avatars/avatar2.png', name: 'Priya Singh', quote: 'My child\'s grades and confidence have soared!', cardBackgroundImage: '/img2.jpg' },
    { id: 3, imageUrl: '/avatars/avatar3.png', name: 'Amit Verma', quote: 'User-friendly interface and reasonable pricing plans!', cardBackgroundImage: '/img3.jpg' },
    { id: 4, imageUrl: '/avatars/avatar4.png', name: 'Sneha Gupta', quote: 'Excellent enquiries from Shampari Edutech. Highly recommended!', cardBackgroundImage: '/img4.jpg' },
    { id: 5, imageUrl: '/avatars/avatar5.png', name: 'Vivek Kumar', quote: 'Shampari Edutech transformed my understanding of complex subjects.', cardBackgroundImage: '/img5.jpg' },
    { id: 6, imageUrl: '/avatars/avatar6.png', name: 'Anjali Desai', quote: 'Finding the right tutor was incredibly easy and efficient.', cardBackgroundImage: '/img6.jpg' },
    { id: 7, imageUrl: '/avatars/avatar7.png', name: 'Manish Patel', quote: 'This platform genuinely cares about student success.', cardBackgroundImage: '/img7.jpg' },
    { id: 8, imageUrl: '/avatars/avatar8.png', name: 'Kavita Rao', quote: 'The tutors are highly qualified and very supportive.', cardBackgroundImage: '/img8.jpg' },
    { id: 9, imageUrl: '/avatars/avatar9.png', name: 'Deepak Sharma', quote: 'I never thought learning could be this engaging.', cardBackgroundImage: '/img9.jpg' },
    { id: 10, imageUrl: '/avatars/avatar10.png', quote: 'A truly fantastic experience from start to finish.', cardBackgroundImage: '/img10.jpg' },
    { id: 11, imageUrl: '/avatars/avatar1.png', name: 'Ravi Kumar', quote: 'Flexible schedules are a real blessing for busy students.', cardBackgroundImage: '/img11.jpg' },
    { id: 12, imageUrl: '/avatars/avatar2.png', name: 'Divya Sharma', quote: 'The best investment I made for my academic future.', cardBackgroundImage: '/img12.jpg' },
    { id: 13, imageUrl: '/avatars/avatar3.png', name: 'Sanjay Gupta', quote: 'Helped me achieve top scores in my exams!', cardBackgroundImage: '/img13.jpg' },
    { id: 14, imageUrl: '/avatars/avatar4.png', name: 'Meena Reddy', quote: 'The tutors are passionate and make learning fun.', cardBackgroundImage: '/img14.jpg' },
    { id: 15, imageUrl: '/avatars/avatar5.png', name: 'Vikram Singh', quote: 'I appreciate the deep knowledge and patience of the tutors.', cardBackgroundImage: '/img15.jpg' },
    { id: 16, imageUrl: '/avatars/avatar6.png', name: 'Swati Agarwal', quote: 'A very encouraging and supportive learning environment.', cardBackgroundImage: '/img16.jpg' },
    { id: 17, imageUrl: '/avatars/avatar7.png', name: 'Ashish Malik', quote: 'The platform connected me with the perfect tutor.', cardBackgroundImage: '/img17.jpg' },
    { id: 18, imageUrl: '/avatars/avatar8.png', name: 'Nisha Singh', quote: 'Highly professional and effective tutoring services.', cardBackgroundImage: '/img18.jpg' },
    { id: 19, imageUrl: '/avatars/avatar9.png', name: 'Gaurav Kumar', quote: 'My confidence in the subject has grown exponentially.', cardBackgroundImage: '/img19.jpg' },
];

const SuccessGrid = ({ data = successData }) => {
    return (
        <div className="py-16 bg-white border-[24px] border-gray-900 min-h-screen relative overflow-hidden">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-20">
                <h2 className="text-4xl sm:text-5xl font-extrabold mb-12 text-gray-800 tracking-tight">
                    Hear From Our Happy Learners & Partners!
                </h2>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    {data.map((item) => (
                        <div
                            key={item.id}
                            className="relative overflow-hidden rounded-xl shadow-xl group cursor-pointer h-80 bg-cover bg-center flex flex-col justify-between transform transition-transform duration-300 hover:scale-105"
                            style={{ backgroundImage: `url(${item.cardBackgroundImage})` }}
                        >


                            <div className="relative  text-white z-10 flex flex-col justify-between h-full p-6">
                                <p className="text-lg italic font-medium mb-4 flex-grow text-black">
                                    "{item.quote}"
                                </p>

                                <div className="flex items-center mt-auto justify-start">
                                    {item.imageUrl && (
                                        <img
                                            src={item.imageUrl}
                                            alt={item.name}
                                            className="w-16 h-16 rounded-full mr-4 object-cover border-3 border-white shadow-lg"
                                            onError={(e) => { e.target.onerror = null; e.target.src = "https://placehold.co/64x64/cccccc/ffffff?text=AV"; }}
                                        />
                                    )}
                                    <div className="text-left">
                                        <p className="font-bold text-xl">{item.name}</p>
                                        <p className="text-sm text-blue-200">{item.designation || 'Learner/Partner'}</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>
        </div>
    );
};

export default SuccessGrid;
