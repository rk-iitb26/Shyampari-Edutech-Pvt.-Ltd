// src/Components/WhyUs.jsx
import React from 'react';

// Define default features data for demonstration/fallback
const defaultWhyUsFeatures = [
  {
    id: 'p1',
    iconSvgPath: `<path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 14c-2.21 0-4-1.79-4-4s1.79-4 4-4 4 1.79 4 4-1.79 4-4 4zm-1.5-5.5h3v2h-3v-2z"></path>`, // Placeholder for user icon
    iconColor: 'text-orange-500', // Example color
    title: 'Personalized Approached one on one at home',
    description: 'Personalized Approach: We understand that every student is unique. Our tutors craft customized lesson plans to cater to each student\'s learning style, pace, and specific needs. One on one helps the child in gaining concepts of previous class and present class going in schools in personalized way',
  },
  {
    id: 'p2',
    iconSvgPath: `<svg xmlns="http://www.w3.org/2000/svg" width="24.5" height="25.5" viewBox="0 0 65 64"><path fill="currentColor" d="M55.896.257H8.895C4.29.257.543 4.005.543 8.611v46.995c0 4.607 3.747 8.356 8.352 8.356h47.001c4.605 0 8.352-3.748 8.352-8.356V8.611c0-4.606-3.746-8.354-8.352-8.354m-6.262 13.495a3.286 3.286 0 0 1 3.288 3.292a3.284 3.284 0 0 1-3.288 3.289a3.29 3.29 0 0 1 0-6.581m1.765 7.864c-.004.371-.036 2.419-.479 3.038c-.489.677-1.287.574-1.287.574s-.9.031-1.256-.522c-.352-.541-.523-1.615-.511-3.09zM10.328 7.144h22.23v15.371l-1.298-1.297V8.444H11.62v24.865h19.64v-7.817l1.298 1.298v7.821h-22.23zm15.7 23.283a1.026 1.026 0 0 1-1.969.576l-2.386-8.188h-.845l-2.387 8.188a1.027 1.027 0 0 1-1.273.696a1.024 1.024 0 0 1-.696-1.272l2.416-8.292v-5.318l-.612.002l-.004-.002L16.9 21.49a.75.75 0 0 1-.928.507a.746.746 0 0 1-.506-.928l1.438-4.887c.572-1.9 2.178-1.843 2.178-1.843h4.337s1.604-.057 2.176 1.843l1.44 4.887a.748.748 0 0 1-1.435.421l-1.374-4.673l-.004.002l-.612-.002v5.321l2.417 8.288zm-6.529-18.392c0-.966.785-1.752 1.751-1.752a1.753 1.753 0 0 1 0 3.504a1.753 1.753 0 0 1-1.751-1.752M35.89 42.09c0 1.826-1.492 3.306-3.332 3.306c-1.842 0-3.334-1.481-3.334-3.306s1.492-3.307 3.334-3.307c1.841 0 3.332 1.481 3.332 3.307m-17.115.029a3.295 3.295 0 1 1-6.59 0a3.295 3.295 0 0 1 6.59 0m3.276 15.248H8.841v-6.458c0-2.329 1.913-4.221 4.245-4.221h4.552c2.331 0 4.414 1.893 4.414 4.221v6.458zm2.478 0l2.624-7.147c1.051-3.651 4.111-3.539 4.111-3.539h2.597s3.058-.112 4.111 3.539l2.624 7.147H24.53zm16.407-26.995h-4.563a1.384 1.384 0 0 1-1.387-1.386c0-.255.188-.658.309-.857l-5.57-5.57a.563.563 0 0 1 .002-.798a.56.56 0 0 1 .797 0l5.853 5.854l4.144.002l2.732-4.122a4.22 4.22 0 0 1 3.512-1.878h.209c-.002.416.031 2.958.891 3.855c.645.646 1.327.59 1.327.59v3.381a1.146 1.146 0 0 0 .441 2.205a1.147 1.147 0 0 0 .439-2.205v-3.366s.782.07 1.446-.736c.636-.79.781-2.593.776-3.679c2.138 0 3.946 2.082 3.946 4.397v8.847H44.75v-8.627c-.306.459-1.343 1.994-2.324 3.451c-.29.436-.971.645-1.489.645zm12.008 11.465a3.3 3.3 0 0 1-3.295 3.298a3.297 3.297 0 0 1 0-6.595a3.296 3.296 0 0 1 3.295 3.297m3.339 15.53H43.077v-6.458c0-2.329 2.079-4.221 4.414-4.221h4.546c2.333 0 4.246 1.892 4.246 4.221z"/></svg>`, // Placeholder for qualified icon
    iconColor: 'text-blue-500',
    title: 'Qualified educators and coordinator support',
    description: 'Qualified Educators: Our team comprises experienced and passionate educators who are dedicated to making learning enjoyable and Impactful. Coordinator support: a coordinator is appointed on institute behalf to look after the daily punctuality and progression of class .',
  },
  {
    id: 'p3',
    iconSvgPath: `<svg xmlns="http://www.w3.org/2000/svg" width="24.5" height="25.5" viewBox="0 0 65 64"><path fill="currentColor" d="M11.231 48.686a4.116 4.116 0 1 1 .001-8.231a4.116 4.116 0 0 1-.001 8.231M2.943 63.612v-8.064c0-2.908 2.389-5.271 5.3-5.271h5.683c2.911 0 5.511 2.363 5.511 5.271v8.064zm50.955-15.275a4.12 4.12 0 0 0 4.115-4.117a4.116 4.116 0 1 0-8.23 0a4.12 4.12 0 0 0 4.115 4.117m8.284 15.275v-8.064c0-2.908-2.389-5.271-5.302-5.271h-5.677c-2.916 0-5.512 2.363-5.512 5.271v8.064h16.49zM32.557 48.664c-2.3 0-4.163-1.849-4.163-4.128s1.863-4.129 4.163-4.129c2.298 0 4.161 1.849 4.161 4.129s-1.862 4.128-4.161 4.128M22.532 63.612l3.276-8.925c1.312-4.559 5.133-4.418 5.133-4.418h3.243s3.819-.14 5.133 4.418l3.276 8.925zm10.025-28.416v-9.765l-1.621-1.621v9.76H6.413V2.522h24.523v15.95l1.621 1.62V.899H4.798v34.296z"/><path fill="currentColor" d="M18.436 9.195a2.19 2.19 0 0 0 0-4.376a2.188 2.188 0 0 0 0 4.376m7.225 9.093s-1.795-6.097-1.798-6.102c-.715-2.373-2.717-2.302-2.717-2.302H15.73s-2.005-.071-2.719 2.302l-1.795 6.102a.933.933 0 1 0 1.79.526l1.714-5.835l.004.002l.764-.002v6.64l-3.017 10.354a1.28 1.28 0 0 0 1.228 1.64c.555 0 1.067-.363 1.231-.921l2.98-10.224h1.055l2.98 10.224a1.28 1.28 0 0 0 1.588.869a1.28 1.28 0 0 0 .87-1.588l-3.017-10.349V12.98l.764.002l.004-.002l1.716 5.835a.932.932 0 1 0 1.79-.526zm28.218-.919a4.11 4.11 0 0 1 0-8.218a4.103 4.103 0 0 1 4.106 4.111a4.1 4.1 0 0 1-4.106 4.107m0 6.111s.997.129 1.607-.716c.552-.772.593-3.33.597-3.793h-4.412c-.015 1.841.199 3.183.639 3.859c.444.69 1.569.651 1.569.651z"/><path fill="currentColor" d="M35.975 27.103c-.151.248-.386.752-.386 1.07c0 .96.775 1.731 1.732 1.731h5.697c.647 0 1.497-.261 1.86-.805c1.225-1.819 2.52-3.736 2.902-4.309v10.772h14.348V24.515c0-2.889-2.257-5.49-4.927-5.49c.007 1.356-.175 3.608-.969 4.594c-.829 1.007-1.805.919-1.805.919v4.203a1.43 1.43 0 0 1-.548 2.754a1.43 1.43 0 0 1-1.431-1.433c0-.595.362-1.105.88-1.321v-4.222s-.852.07-1.657-.737c-1.075-1.12-1.115-4.294-1.113-4.813h-.261a5.26 5.26 0 0 0-4.385 2.346l-3.411 5.147l-5.175-.002l-7.308-7.309a.7.7 0 0 0-.995 0a.704.704 0 0 0-.002.997l6.955 6.956z"/></svg>`, // Placeholder for counselling icon
    iconColor: 'text-purple-500',
    title: 'Counselling session & career guidance',
    description: 'counselling is given to child time to time along with daily session to track improvement and understand the child mindset. career guidance from our expert team of teachers is been given to child to make child exceed in respective field line.',
  },
  {
    id: 'p4',
    iconSvgPath: `<svg xmlns="http://www.w3.org/2000/svg" width="24.5" height="25.5" viewBox="0 0 65 64"><path fill="currentColor" d="M55.896.257H8.895C4.29.257.543 4.005.543 8.611v46.995c0 4.607 3.747 8.356 8.352 8.356h47.001c4.605 0 8.352-3.748 8.352-8.356V8.611c0-4.606-3.746-8.354-8.352-8.354m-6.262 13.495a3.286 3.286 0 0 1 3.288 3.292a3.284 3.284 0 0 1-3.288 3.289a3.29 3.29 0 0 1 0-6.581m1.765 7.864c-.004.371-.036 2.419-.479 3.038c-.489.677-1.287.574-1.287.574s-.9.031-1.256-.522c-.352-.541-.523-1.615-.511-3.09zM10.328 7.144h22.23v15.371l-1.298-1.297V8.444H11.62v24.865h19.64v-7.817l1.298 1.298v7.821h-22.23zm15.7 23.283a1.026 1.026 0 0 1-1.969.576l-2.386-8.188h-.845l-2.387 8.188a1.027 1.027 0 0 1-1.273.696a1.024 1.024 0 0 1-.696-1.272l2.416-8.292v-5.318l-.612.002l-.004-.002L16.9 21.49a.75.75 0 0 1-.928.507a.746.746 0 0 1-.506-.928l1.438-4.887c.572-1.9 2.178-1.843 2.178-1.843h4.337s1.604-.057 2.176 1.843l1.44 4.887a.748.748 0 0 1-1.435.421l-1.374-4.673l-.004.002l-.612-.002v5.321l2.417 8.288zm-6.529-18.392c0-.966.785-1.752 1.751-1.752a1.753 1.753 0 0 1 0 3.504a1.753 1.753 0 0 1-1.751-1.752M35.89 42.09c0 1.826-1.492 3.306-3.332 3.306c-1.842 0-3.334-1.481-3.334-3.306s1.492-3.307 3.334-3.307c1.841 0 3.332 1.481 3.332 3.307m-17.115.029a3.295 3.295 0 1 1-6.59 0a3.295 3.295 0 0 1 6.59 0m3.276 15.248H8.841v-6.458c0-2.329 1.913-4.221 4.245-4.221h4.552c2.331 0 4.414 1.893 4.414 4.221v6.458zm2.478 0l2.624-7.147c1.051-3.651 4.111-3.539 4.111-3.539h2.597s3.058-.112 4.111 3.539l2.624 7.147H24.53zm16.407-26.995h-4.563a1.384 1.384 0 0 1-1.387-1.386c0-.255.188-.658.309-.857l-5.57-5.57a.563.563 0 0 1 .002-.798a.56.56 0 0 1 .797 0l5.853 5.854l4.144.002l2.732-4.122a4.22 4.22 0 0 1 3.512-1.878h.209c-.002.416.031 2.958.891 3.855c.645.646 1.327.59 1.327.59v3.381a1.146 1.146 0 0 0 .441 2.205a1.147 1.147 0 0 0 .439-2.205v-3.366s.782.07 1.446-.736c.636-.79.781-2.593.776-3.679c2.138 0 3.946 2.082 3.946 4.397v8.847H44.75v-8.627c-.306.459-1.343 1.994-2.324 3.451c-.29.436-.971.645-1.489.645zm12.008 11.465a3.3 3.3 0 0 1-3.295 3.298a3.297 3.297 0 0 1 0-6.595a3.296 3.296 0 0 1 3.295 3.297m3.339 15.53H43.077v-6.458c0-2.329 2.079-4.221 4.414-4.221h4.546c2.333 0 4.246 1.892 4.246 4.221z"/></svg>`, // Placeholder for group tuition icon
    iconColor: 'text-teal-500',
    title: 'Group tuition batch 3/5 students',
    description: 'we have introduced group tuitions where 3 students one teacher or 5 students one teacher of same/different class can study together with reasonable fee and high Quality education at your home .flexibility of timings and teacher as per parents need.',
  },
];

function WhyUs({ features = defaultWhyUsFeatures }) {
  return (
    <div className="w-full bg-gray-100 py-16 sm:py-24 text-gray-900"> {/* Light background matching the screenshot */}
      {/* Title */}
      <h2 className="text-4xl sm:text-5xl font-bold text-center mb-12 sm:mb-16">
        Why Shampari Edutech?
      </h2>

      {/* Features Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
        {features.map((feature) => (
          <div key={feature.id} className="bg-white rounded-lg p-6 flex flex-col items-center text-center">
            {/* Icon */}
            <div className={`w-20 h-20 flex items-center justify-center mb-6`}>
              {/* Replace with your actual SVG icons. Use dangerouslySetInnerHTML with caution. */}
              {/* Better approach: import actual SVG components or use <img> for SVG files */}
              <svg className={`w-full h-full ${feature.iconColor}`} fill="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"
                dangerouslySetInnerHTML={{ __html: feature.iconSvgPath }}></svg>
            </div>

            {/* Title */}
            <h3 className="text-xl sm:text-2xl font-semibold mb-3">{feature.title}</h3>

            {/* Description */}
            <p className="text-base text-gray-700 leading-relaxed">
              {feature.description}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
}

export default WhyUs;