import { useState } from "react";
import { Menu, X } from "lucide-react";
import { Link, useNavigate } from "react-router-dom"; // ✅ Import navigation hook
import LoginPage from "../Pages/Login";

function NavBar({ About, Event, Contact, Feedback }) {

    const [menuOpen, setMenuOpen] = useState(false);
    const navigate = useNavigate(); // ✅ Create navigate function

    const handleLoginClick = () => {
        navigate("/login")
        setMenuOpen(false);
    };

    const handleSignUpClick = () => {
        navigate("/signup"); // ✅ Navigate to signup page
        setMenuOpen(false);
    };

    const handleFeedBacks = () => {
        navigate("/feedbacks");
        setMenuOpen(false);
    }

    return (
        <nav className="w-full bg-black text-white sticky top-0 font-Ubuntu z-50">
            <div className="w-full flex items-center justify-between p-4 md:px-16 h-full gap-4">

                {/* Logo Section */}
                <div className="flex items-center gap-4">
                    <img
                        src="/logo.png"
                        alt="Shampari-logo"
                        className="h-14 w-auto object-contain rounded-sm"
                    />
                    <div className="text-2xl md:text-3xl font-semibold text-white">
                        Shampari Edutech Pvt.Ltd
                    </div>
                </div>

                {/* Desktop Navigation Links */}
                <div className="hidden md:flex justify-around text-lg font-medium text-white gap-10">
                    <a href="#about" className="hover:underline">{About}</a>
                    <a href="#event" className="hover:underline">{Event}</a>
                    <a href="#contact" className="hover:underline">{Contact}</a>
                    <Link to="/feedbacks" className="hover:underline">{Feedback}</Link>


                </div>

                {/* Desktop Buttons */}
                <div className="hidden md:flex gap-4">
                    <button
                        onClick={handleLoginClick}
                        className="bg-white text-black px-4 py-2 rounded-full">
                        Login
                    </button>
                    <button
                        onClick={handleSignUpClick} // ✅ Navigate to signup
                        className="bg-white text-black px-4 py-2 rounded-full">
                        SignUp
                    </button>
                </div>

                {/* Mobile Menu Icon */}
                <div className="md:hidden text-white z-50">
                    {menuOpen ? (<X size={28} onClick={() => setMenuOpen(false)} />) :
                        (<Menu size={28} onClick={() => setMenuOpen(true)} />)}
                </div>
            </div>

            {/* Mobile Menu */}
            {menuOpen && (
                <div className="flex flex-col items-center bg-black text-white p-4 space-y-4 md:hidden">
                    <a href="#about" onClick={() => setMenuOpen(false)}>About</a>
                    <a href="#event" onClick={() => setMenuOpen(false)}>Event</a>
                    <a href="#contact" onClick={() => setMenuOpen(false)}>Contact</a>
                    <Link to="/feedbacks" className="hover:underline">{Feedback}</Link>
                    <button
                        onClick={handleLoginClick}
                        className="bg-white text-black px-4 py-2 rounded-full">
                        Login
                    </button>
                    <button
                        onClick={handleSignUpClick} // ✅ Navigate to signup
                        className="bg-white text-black px-4 py-2 rounded-full">
                        SignUp
                    </button>
                </div>
            )}

            {/* {showLogin && <LoginPage onclose={() => setShowLogin(false)} />} */}
        </nav>
    );
}

export default NavBar;
