// src/Components/Testimonials.jsx
import React from 'react';
import { useNavigate } from 'react-router-dom';

// Updated: Add a 'cardImage' property to each testimonial for the background image
const defaultTestimonials = [
    {
        id: 't1',
        quote: 'Shampari Edutech has been really beneficial in fetching us leads and boosting our business. Shampari Services are really commendable. We are happy to be a part of Shampari\'s family.',
        author: 'Kreative Language Hub',
        designation: 'Languages',
        image: '/avatars/kreative-language-hub.png',
        cardImage: './img1.jpg'
    },
    {
        id: 't2',
        quote: 'Shampari Edutech has helped us in reaching out to more people interested in film making. Applicants get to know about different film making workshops, compare and choose the best.',
        author: 'Goldenagefilmhouse',
        designation: 'Film making',
        image: './img1.jpg',
        cardImage: './img12.jpg'
    },
    {
        id: 't3',
        quote: 'Shampari Edutech is a great platform with its user-friendly interface, customer friendly executives & reasonable pricing plans, which help us in growing our coaching classes.',
        author: 'Success Sutras',
        designation: 'IELTS',
        image: '/avatars/success-sutras.png',
        cardImage: './img13.jpg'
    },
    {
        id: 't4',
        quote: 'Wonderful website. Excellent enquiries from Shampari Edutech. I am getting Students from Different universities outside India, and different Multinational companies.',
        author: 'VG Reddy',
        designation: 'VBA Trainer',
        image: '/avatars/vg-reddy.png',
        cardImage: './img14.jpg'
    },
    {
        id: 't5',
        quote: 'Shampari Edutech transformed my understanding of complex subjects. The personalized guidance made all the difference!',
        author: 'Priya Sharma',
        designation: 'Student',
        image: '/avatars/student1.png',
        cardImage: './img5.jpg'
    },
    {
        id: 't6',
        quote: 'As a parent, I am incredibly impressed with the dedication of Shampari Edutech tutors. My child\'s grades and confidence have soared!',
        author: 'Rajesh Kumar',
        designation: 'Parent',
        image: '/avatars/parent1.png',
        cardImage: './img6.jpg'
    }
];

function Testimonials({ testimonials = defaultTestimonials }) {
    const navigate = useNavigate();
    const displayedTestimonials = testimonials.slice(0, 4);

    const handleNavigation = () => {
        navigate('/feedbacks');
    };

    return (
        <div className="w-full py-16 sm:py-24 text-gray-900 bg-gray-100">
            <h2 className="text-4xl sm:text-5xl font-bold text-center mb-12 sm:mb-16">
                What Our Students & Parents Say
            </h2>

            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
                <button
                    onClick={handleNavigation}
                    className="absolute left-0 top-1/2 -translate-y-1/2 bg-gray-700 hover:bg-gray-800 text-white p-3 rounded-full shadow-lg focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-opacity-50 z-20 hidden md:block"
                    aria-label="View more testimonials"
                >
                    <i className="fas fa-arrow-left text-xl"></i>
                </button>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                    {displayedTestimonials.map((testimonial) => (
                        <div
                            key={testimonial.id}
                            className="relative rounded-lg overflow-hidden shadow-lg p-6 flex flex-col justify-between text-white bg-cover bg-center h-80"
                            style={{ backgroundImage: `url(${testimonial.cardImage})` }}
                        >
                            {/* Overlay to darken image and make text readable */}
                            <div className="absolute inset-0 bg-black opacity-50 z-0"></div>

                            {/* Content is placed here, above the overlay */}
                            <div className="relative z-10 flex flex-col justify-between h-full">
                                <p className="text-base flex-grow italic font-semibold">
                                    "{testimonial.quote}"
                                </p>
                                <div className="flex items-center mt-4">
                                    {testimonial.image && (
                                        <img
                                            src={testimonial.image}
                                            alt={testimonial.author}
                                            className="w-12 h-12 rounded-full mr-4 object-cover border-2 border-white"
                                        />
                                    )}
                                    <div>
                                        <p className="font-semibold text-lg">{testimonial.author}</p>
                                        <p className="text-sm text-gray-200">{testimonial.designation}</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>

                <button
                    onClick={handleNavigation}
                    className="absolute right-0 top-1/2 -translate-y-1/2 bg-gray-700 hover:bg-gray-800 text-white p-3 rounded-full shadow-lg focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-opacity-50 z-20 hidden md:block"
                    aria-label="View more testimonials"
                >
                    <i className="fas fa-arrow-right text-xl"></i>
                </button>
            </div>

            <div className="mt-8 text-center">
                <button
                    onClick={handleNavigation}
                    className="bg-black text-white font-semibold py-2 px-6 rounded-full shadow-md hover:bg-gray-800 transition-colors"
                >
                    View All Feedbacks
                </button>
            </div>
        </div>
    );
}

export default Testimonials;